def add(i, j):
    pass

class Pet:
    """
    # test
    """
    def __init__(self, name):
        self.name = name
        pass
    pass