import setuptools

setuptools.setup(
    name = "pybind_study",
    version = "0.0.1",
    description = "pybind_study",
    author = "<NAME>",
    author_email = "<EMAIL>",
    url="https://github.com/hurleykane/pybind_study",
    packages=setuptools.find_packages("."),
    package_data = {
        # 引入任何包下的pyd文件，加入字典则对应包下的文件
        "core": ["*.pyd"]
    },
)