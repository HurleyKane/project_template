from Cplus.core import function

__all__ = ["function"]
